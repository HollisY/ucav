<?php
header ( 'Content-Type: text/html; charset=UTF-8' );
// App Key
define ( "APP_KEY", '3e1bf57ecfb04f17b7b700be05e7fab7' );
// App Secret
define ( "APP_SECRET", 'f18022b515f440378ae23e2758561d5f' );
// 应用回调页地址
define ( "CALLBACK_URL", "http://zisheng.org/rrcallback.php" );

