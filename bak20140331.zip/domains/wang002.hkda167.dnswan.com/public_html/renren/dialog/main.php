<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
</head>
<body>
<hr>
人人API(基于APP)：<br>
<a  href="./api/feed.php" >API同步新鲜事</a><br>
<a  href="./api/photo.php" >上传照片</a><br>
<hr>
人人分享（不基于APP）：<br>
<a  href="./share/share.html" >人人分享</a>
<hr>
人人Dialog（基于APP）：<br>
<a  href="./dialog/feedDialogIframe.php" >弹出新鲜事弹层(iframe，弹层实现还基于access_token)</a><br>
<a  href="./dialog/feedDialogPopup.php" >弹出新鲜事弹窗(popup)</a><br>
<a  href="./dialog/requestDialogIframe.php" >弹出邀请好友弹层(iframe，弹层实现还基于access_token)</a><br>
<a  href="./dialog/requestDialogPopup.php" >弹出邀请好友弹窗(popup)</a><br>
<hr>
<br><a  href="index.php" >退出</a>
</body>
</html>