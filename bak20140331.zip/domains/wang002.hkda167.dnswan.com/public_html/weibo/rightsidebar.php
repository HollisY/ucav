<div id="rp_list" class="rp_list">
	<ul>
		<li>
			<div>
				<img src="images/1.jpg" alt=""/>
				<span class="rp_title">Beautiful Background Image Navigation</span>
				<span class="rp_links">
					<a target="_blank" href="">Article</a>
					<a target="_blank" href="">Demo</a>
				</span>
			</div>
		</li>
		<li>
			<div>
				<img src="images/2.jpg" alt=""/>
				<span class="rp_title">Awesome Bubble Navigation with jQuery</span>
				<span class="rp_links">
					<a target="_blank" href="">Article</a>
					<a target="_blank" href="">Demo</a>
				</span>
			</div>
		</li>
		<li>
			<div>
				<img src="images/3.jpg" alt=""/>
				<span class="rp_title">Stunning Circular Motion Effect with jQuery</span>
				<span class="rp_links">
					<a target="_blank" href="">Article</a>
					<a target="_blank" href="">Demo</a>
				</span>
			</div>
		</li>
		<li>
			<div>
				<img src="images/4.jpg" alt=""/>
				<span class="rp_title">Fresh Set of CSS-only Menus</span>
				<span class="rp_links">
					<a target="_blank" href="">Article</a>
					<a target="_blank" href="">Demo</a>
				</span>
			</div>
		</li>
		<li>
			<div>
				<img src="images/5.jpg" alt=""/>
				<span class="rp_title">Fresh Sliding Thumbnails Gallery</span>
				<span class="rp_links">
					<a target="_blank" href="">Article</a>
					<a target="_blank" href="">Demo</a>
				</span>
			</div>
		</li>
		<li>
			<div>
				<img src="images/6.jpg" alt=""/>
				<span class="rp_title">A jQuery Heat Map</span>
				<span class="rp_links">
					<a target="_blank" href="">Article</a>
					<a target="_blank" href="">Demo</a>
				</span>
			</div>
		</li>
		<li>
			<div>
				<img src="images/7.jpg" alt=""/>
				<span class="rp_title">jTextTranslate: A jQuery Translation Plugin</span>
				<span class="rp_links">
					<a target="_blank" href="">Article</a>
					<a target="_blank" href="">Demo</a>
				</span>
			</div>
		</li>
		<li>
			<div>
				<img src="images/8.jpg" alt=""/>
				<span class="rp_title">Awesome Mobile Image Gallery Web App</span>
				<span class="rp_links">
					<a target="_blank" href="">Article</a>
					<a target="_blank" href="">Demo</a>
				</span>
			</div>
		</li>
		<li>
			<div>
				<img src="images/13.jpg" alt=""/>
				<span class="rp_title">Awesome CSS3 & jQuery Slide Out Button</span>
				<span class="rp_links">
					<a target="_blank" href="">Article</a>
					<a target="_blank" href="">Demo</a>
				</span>
			</div>
		</li>
		<li>
			<div>
				<img src="images/14.jpg" alt=""/>
				<span class="rp_title">Beautiful Slide Out Navigation</span>
				<span class="rp_links">
					<a target="_blank" href="">Article</a>
					<a target="_blank" href="">Demo</a>
				</span>
			</div>
		</li>
		<li>
			<div>
				<img src="images/9.jpg" alt=""/>
				<span class="rp_title">Neat Photo Hover Effect with CSS Sprites and jQuery</span>
				<span class="rp_links">
					<a target="_blank" href="">Article</a>
					<a target="_blank" href="">Demo</a>
				</span>
			</div>
		</li>
		<li>
			<div>
				<img src="images/10.jpg" alt=""/>
				<span class="rp_title">Beautiful Photo Stack Gallery</span>
				<span class="rp_links">
					<a target="_blank" href="">Article</a>
					<a target="_blank" href="">Demo</a>
				</span>
			</div>
		</li>
		<li>
			<div>
				<img src="images/11.jpg" alt=""/>
				<span class="rp_title">Pimp Your Tables with CSS3</span>
				<span class="rp_links">
					<a target="_blank" href="">Article</a>
					<a target="_blank" href="">Demo</a>
				</span>
			</div>
		</li>
		<li>
			<div>
				<img src="images/12.jpg" alt=""/>
				<span class="rp_title">Scrolling to the Top and Bottom with jQuery</span>
				<span class="rp_links">
					<a target="_blank" href="">Article</a>
					<a target="_blank" href="">Demo</a>
				</span>
			</div>
		</li>
		<li>
			<div>
				<img src="images/15.jpg" alt=""/>
				<span class="rp_title">Awesome Cufonized Fly-out Menu</span>
				<span class="rp_links">
					<a target="_blank" href="">Article</a>
					<a target="_blank" href="">Demo</a>
				</span>
			</div>
		</li>
		<li>
			<div>
				<img src="images/16.jpg" alt=""/>
				<span class="rp_title">Minimalistic Slideshow Gallery with jQuery</span>
				<span class="rp_links">
					<a target="_blank" href="">Article</a>
					<a target="_blank" href="">Demo</a>
				</span>
			</div>
		</li>
		<li>
			<div>
				<img src="images/17.jpg" alt=""/>
				<span class="rp_title">Interactive Photo Desk with jQuery and CSS3</span>
				<span class="rp_links">
					<a target="_blank" href="">Article</a>
					<a target="_blank" href="">Demo</a>
				</span>
			</div>
		</li>
		<li>
			<div>
				<img src="images/18.jpg" alt=""/>
				<span class="rp_title">Sliding Panel Photo Wall Gallery with jQuery</span>
				<span class="rp_links">
					<a target="_blank" href="">Article</a>
					<a target="_blank" href="">Demo</a>
				</span>
			</div>
		</li>
		<li>
			<div>
				<img src="images/19.jpg" alt=""/>
				<span class="rp_title">Slide Down Box Menu with jQuery and CSS3</span>
				<span class="rp_links">
					<a target="_blank" href="">Article</a>
					<a target="_blank" href="">Demo</a>
				</span>
			</div>
		</li>
		<li>
			<div>
				<img src="images/20.jpg" alt=""/>
				<span class="rp_title">Multimedia Gallery for Images, Video and Audio</span>
				<span class="rp_links">
					<a target="_blank" href="">Article</a>
					<a target="_blank" href="">Demo</a>
				</span>
			</div>
		</li>
	</ul>

	<span id="rp_shuffle" class="rp_shuffle">
	</span>
</div>
<script type="text/javascript" src="js/jquery.js"></script>
<script>
	$(function() {
		/**
		* the list of posts
		*/
		var $list 		= $('#rp_list ul');
		/**
		* number of related posts
		*/
		var elems_cnt 		= $list.children().length;
		
		/**
		* show the first set of posts.
		* 200 is the initial left margin for the list elements
		*/
		load(200);
		
		function load(initial){
			$list.find('li').hide().andSelf().find('div').css('margin-left',-initial+'px');
			var loaded	= 0;
			//show 5 random posts from all the ones in the list. 
			//Make sure not to repeat
			while(loaded < 5){
				var r 		= Math.floor(Math.random()*elems_cnt);
				var $elem	= $list.find('li:nth-child('+ (r+1) +')');
				if($elem.is(':visible'))
					continue;
				else
					$elem.show();
				++loaded;
			}
			//animate them
			var d = 200;
			$list.find('li:visible div').each(function(){
				$(this).stop().animate({
					'marginLeft':'-50px'
				},d += 100);
			});
		}
			
		/**
		* hovering over the list elements makes them slide out
		*/	
		$list.find('li:visible').live('mouseenter',function () {
			$(this).find('div').stop().animate({
				'marginLeft':'-220px'
			},200);
		}).live('mouseleave',function () {
			$(this).find('div').stop().animate({
				'marginLeft':'-50px'
			},200);
		});
		
		/**
		* when clicking the shuffle button,
		* show 5 random posts
		*/
		$('#rp_shuffle').unbind('click')
						.bind('click',shuffle)
						.stop()
						.animate({'margin-left':'-18px'},700);
						
		function shuffle(){
			$list.find('li:visible div').stop().animate({
				'marginLeft':'60px'
			},200,function(){
				load(-60);
			});
		}
});
</script>
