<?php
header('Content-Type: text/html; charset=UTF-8');

define( "WB_AKEY" , '2801729079' );
define( "WB_SKEY" , '2b1293bde7580a146d812c5dfcc5028b' );
define( "WB_CALLBACK_URL" , 'http://zisheng.org/callback.php' );
