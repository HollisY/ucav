renren-api2-sdk-php
===================

renren-api2-sdk-php 是对人人 API 2.0 接口进行了一个简单封装，主要包括了 OAuth 2.0 认证、接口调用。

具体SDK的使用，请浏览<http://wiki.dev.renren.com/wiki/V2/sdk/php_sdk>。
