<div class="header">
        <ul id="navigation">
                <li><a href="http://zisheng.org">H<p>首页</p></a></li> 
                <li><a href="http://zisheng.org/new.php">t<p>朋友墙</p></a></li>
                <li><a href="http://zisheng.org/huying">b<p>呼应</p></a></li>
                <li><a href="http://zisheng.org/aboutus.php">i<p>我们</p></a></li>
                <li><a href="http://zisheng.org/me/regi.php">w<p>DIY简历</p></a></li>
        </ul>
</div>

<script type="text/javascript" src="http://zisheng.org/js/jquery.js"></script>
<script type="text/javascript" src="http://zisheng.org/js/header-navi.js"></script>