
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>吱声</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="吱声" />
<meta name="description" content="吱声" />
<link rel="shortcut icon" href="Favicon.ico" mce_href="Favicon.ico" type="image/x-icon">
<link rel="stylesheet" type="text/css" href="css/headerstyle.css" />
<link rel="stylesheet" type="text/css" href="css/style.css" />

</head>
<body>
<?php
   include_once"header-navi.php";
?>

  <div class="search">
      <span>搜一搜吱声</span>
     <script>
  (function() {
    var cx = '004946305775346921850:efckhdu-yhm';
    var gcse = document.createElement('script');
    gcse.type = 'text/javascript';
    gcse.async = true;
    gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
        '//www.google.com/cse/cse.js?cx=' + cx;
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(gcse, s);
  })();
</script>
<gcse:search></gcse:search>
  </div>
 </body>
</html>