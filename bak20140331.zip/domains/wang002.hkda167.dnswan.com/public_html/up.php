<form enctype="multipart/form-data" method="POST" action="fileload.php" name="myform" >
    <table>
        <input type="text" name="filename" />
        <input type="file" name="myfile" />
        <input type="submit" value="uploadlogo" />
    </table>
</form>