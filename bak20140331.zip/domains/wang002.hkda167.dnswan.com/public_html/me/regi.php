<!DOCTYPE html>
<html lang="zh">
    <head>
        <title>吱声--简历制作</title>
	<meta name="keywords" content="吱声简历制作" />
	<meta name="description" content="吱声简历制作" />
	<link rel="shortcut icon" href="../Favicon.ico" mce_href="../Favicon.ico" type="image/x-icon">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta chaset="uft-8" />
        <meta name="viewport" content="width=device-width,initial-scale=1.0" />
        <script src="js/jquery.js" ></script>
        <link href="css/style.css" rel="stylesheet" />
        <link href="../css/headerstyle.css" rel="stylesheet" />
    </head>
    <body>
        <header>
            <?php include_once"../header-navi.php" ;?>
        </header>
        <?php
            session_start();
            //weibologin
            include_once( '../weibo/config.php' );
            include_once( '../weibo/weibofun.php' );
            include_once('../config.php');
            include_once('../zsdb.php');
            $weibo = new SaeTClientV2( WB_AKEY , WB_SKEY , $_SESSION['token']['access_token'] );
            $uid_json = $weibo->get_uid();
            $wbuid = $uid_json['uid']; //当前登录用户的uid
            $wbprofile=$weibo->show_user_by_id($wbuid);//当前登录uid的基本信息，参考http://open.weibo.com/wiki/2/users/show
            
            //renrenlogin
            include_once ('../ren/config.php');
            include_once ('../ren/rennclient/RennClient.php');
            $rennClient = new RennClient ( APP_KEY, APP_SECRET );
            $rennClient->setDebug ( DEBUG_MODE );  
            // 生成state并存入SESSION，以供CALLBACK时验证使用
            $state = uniqid ( 'renren_', true );
            $_SESSION ['renren_state'] = $state;
            // 得认证授权的url
            $rrcode_url = $rennClient->getAuthorizeURL ( CALLBACK_URL, 'code', $state );
            if(isset($_SESSION['rraccess_token']))
            {
             $rraccess_token==$_SESSION['rraccess_token'];
              //登录信息
              $renn_client = new RennClient ( APP_KEY, APP_SECRET );
              $renn_client->setDebug ( DEBUG_MODE );
              // 获得保存的token
              $renn_client->authWithStoredToken ();
              // 获得用户接口
              $renren_service = $renn_client->getUserService ();
              // 获得当前登录用户
              $renren= $renren_service->info();
              $rruid=$renren[id];
              $rrname=$renren['name'];
              $rrtinyurl=$renren['avatar'][0]['url'];
            }
            
            
        ?>
        <div class="mainwrapper" >
            <div id="content" style="margin-left: auto; margin-right:auto;float: none">
            <form method="post" action="create.php" enctype="multipart/form-data"><!--enctype="multipart/form-data"-->
                <section id="link0">
                <fieldset>
                    <legend>基本信息</legend>
                    <div class="sec-content">
                        TIPS:
                            <p>0.<a href="http://zisheng.org/me" target="_blanket">看看最终效果</a></p>
                            <p>1.您的照片最终显示大小为100px（宽）×166px（高），请大致保持这个比例以免走形；</p>
                            <p>2.表格内容请填满，内容简洁可以给人清爽的感觉；登陆后您可以删除自己的简历</p>
                            <p>3.因为vps和域名的费用由我个人承担，网站不盈利，如果这个帮助到了您，</p>
                            <p>&nbsp希望您可以捐5元或者10元给我的<a href="http://me.alipay.com/heavencme" target="_blanket">支付宝</a></p>
                            <p>4.需要任何个性定制或者发现任何bug可以QQ联系我<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=24779494&site=qq&menu=yes"><img border="0" src="http://wpa.qq.com/pa?p=2:24779494:41" alt="我的QQ" title="我的QQ"/></a></p>
                            <p>5.祝朋友们、也祝我在求职路上顺利<script type="text/javascript" src="http://widget.renren.com/js/rrshare.js"></script>
                                <a name="xn_share" onclick="shareClick()" type="button_medium" href="javascript:;"></a>
                                <script type="text/javascript">
                                        function shareClick() {
                                                var rrShareParam = {
                                                        resourceUrl : '',	//分享的资源Url
                                                        srcUrl : '',	//分享的资源来源Url,默认为header中的Referer,如果分享失败可以调整此值为resourceUrl试试
                                                        pic : '',		//分享的主题图片Url
                                                        title : '',		//分享的标题
                                                        description : ''	//分享的详细描述
                                                };
                                                rrShareOnclick(rrShareParam);
                                        }
                                </script>
                                <script type="text/javascript" charset="utf-8">
                                (function(){
                                  var _w = 106 , _h = 58;
                                  var param = {
                                    url:location.href,
                                    type:'5',
                                    count:'1', /**是否显示分享数，1显示(可选)*/
                                    appkey:'2801729079', /**您申请的应用appkey,显示分享来源(可选)*/
                                    title:'吱声--DIY简历', /**分享的文字内容(可选，默认为所在页面的title)*/
                                    pic:'', /**分享图片的路径(可选)*/
                                    ralateUid:'2528248397', /**关联用户的UID，分享微博会@该用户(可选)*/
                                    language:'zh_cn', /**设置语言，zh_cn|zh_tw(可选)*/
                                    dpc:1
                                  }
                                  var temp = [];
                                  for( var p in param ){
                                    temp.push(p + '=' + encodeURIComponent( param[p] || '' ) )
                                  }
                                  document.write('<iframe allowTransparency="true" frameborder="0" scrolling="no" src="http://service.weibo.com/staticjs/weiboshare.html?' + temp.join('&') + '" width="'+ _w+'" height="'+_h+'"></iframe>')
                                })()
                                </script>
                                
                            </p>
                    </div>    
                    <div class="sec-header">
                        <h1>
                            <span class="about">我</span>&nbsp;<small>about&nbsp;me</small>
                        </h1>
                    </div>
                    <div id="sec-content-1">
                        <table>
                            <tbody>
                                <tr>
                                    <td style="border-top:0px;">姓名</td>
                                    <td colspan="2" style="border-top:0px;"><input name="nbname" type="text" placeholder="e.g.<?php if(isset($rrname)) echo"$rrname";else echo"王某"; ?>" required aria-required="true" autofocus /></td>
                                    <td rowspan="4" style="border-top:0px;"><img id="uphoto" src="../images/noname.gif"></img><input type="file" name="myfile" size="5" /></td>
                                </tr>
                                <tr>
                                    <td>电子邮箱</td>
                                    <td colspan="2"><input name="nbemail" type="email" placeholder="e.g. wangbin@2love.im" required aria-required="true" /></td>
                                </tr>
                                <tr>
                                    <td>手机号</td>
                                    <td colspan="2"><input name="nbphone" type="tel" placeholder="只有可信用户才可以看到" required aria-required="true" /></td>
                                </tr>
                                <tr>
                                    <td>学校</td>
                                    <td colspan="2"><input name="nbschool" type="text" placeholder="e.g. 南京航空航天大学" required aria-required="true" /></td>
                                </tr>
                                <tr>
                                    <td>学历：</td>
                                    <td><input name="nbdegree" type="text" placeholder="e.g. 本科（大四）" required aria-required="true" /></td>
                                    <td>专业：</td>
                                    <td><input name="nbmajor" type="text" placeholder="e.g. 自动化" required aria-required="true" /></td>
                                </tr>
                                <tr>
                                    <td><input name="nbinfo1" type="text" placeholder="e.g. 四级：" required aria-required="true" /></td>
                                    <td><input name="nbinfoval1" type="text" placeholder="e.g. 591" required aria-required="true" /></td>
                                    <td><input name="nbinfo2" type="text" placeholder="e.g. 雅思：" required aria-required="true" /></td>
                                    <td><input name="nbinfoval2" type="text" placeholder="e.g. 6.5" required aria-required="true" /></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </fieldset>
                </section>
                
                <section id="link1">
                <fieldset>
                    <legend>栏目一</legend>
                    <div class="sec-header">
                        <h1>
                            <span class="about"><input name="nbitem1_name" type="text" placeholder="e.g. 项目经历" required aria-required="true" /></span>&nbsp;<small>NO.1</small>
                        </h1>
                    </div>
                    <div class="sec-content">	
                        <table class="content-table">
                                <thead>
                                        <tr>
                                                <td><strong><input name="nbitem1_col1_name" type="text" placeholder="e.g. 项目" required aria-required="true" /></strong></td>
                                                <td><strong><input name="nbitem1_col2_name" type="text" placeholder="e.g. 类型" required aria-required="true" /></strong></td>
                                                <td><strong><input name="nbitem1_col3_name" type="text" placeholder="e.g. 概述" required aria-required="true" /></strong></td>
                                        </tr>
                                </thead>
                                <tbody>
                                        <tr>
                                                <td><input name="nbitem1_11_val" type="text" /></td>
                                                <td><input name="nbitem1_12_val" type="text" /></td>
                                                <td><input name="nbitem1_13_val" type="text" /></td>
                                        </tr>
                                        <tr>
                                                <td><input name="nbitem1_21_val" type="text" /></td>
                                                <td><input name="nbitem1_22_val" type="text" /></td>
                                                <td><input name="nbitem1_23_val" type="text" /></td>
                                        </tr>
                                        <tr>
                                                <td><input name="nbitem1_31_val" type="text" /></td>
                                                <td><input name="nbitem1_32_val" type="text" /></td>
                                                <td><input name="nbitem1_33_val" type="text" /></td>
                                        </tr>
                                </tbody>
                        </table>
                    </div>
                </fieldset>
                </section>
                
                <section id="link2">
                <fieldset>
                    <legend>栏目二</legend>
                    <div class="sec-header">
                        <h1>
                            <span class="about"><input name="nbitem2_name" type="text" placeholder="e.g. 竞赛获奖" /></span>&nbsp;<small>NO.2</small>
                        </h1>
                    </div>
                    <div class="sec-content">	
                        <table class="content-table">
                                <thead>
                                        <tr>
                                                <td><strong><input name="nbitem2_col1_name" type="text" placeholder="e.g. 名称"  /></strong></td>
                                                <td><strong><input name="nbitem2_col2_name" type="text" placeholder="e.g. 奖项"  /></strong></td>
                                                <td><strong><input name="nbitem2_col3_name" type="text" placeholder="e.g. 时间"  /></strong></td>
                                        </tr>
                                </thead>
                                <tbody>
                                        <tr>
                                                <td><input name="nbitem2_11_val" type="text" /></td>
                                                <td><input name="nbitem2_12_val" type="text" /></td>
                                                <td><input name="nbitem2_13_val" type="text" /></td>
                                        </tr>
                                        <tr>
                                                <td><input name="nbitem2_21_val" type="text" /></td>
                                                <td><input name="nbitem2_22_val" type="text" /></td>
                                                <td><input name="nbitem2_23_val" type="text" /></td>
                                        </tr>
                                        <tr>
                                                <td><input name="nbitem2_31_val" type="text" /></td>
                                                <td><input name="nbitem2_32_val" type="text" /></td>
                                                <td><input name="nbitem2_33_val" type="text" /></td>
                                        </tr>
                                </tbody>
                        </table>
                    </div>
                </fieldset>
                </section>
                <section id="link3">
                <fieldset>
                    <legend>栏目三</legend>
                    <div class="sec-header">
                        <h1>
                            <span class="about"><input name="nbitem3_name" type="text" placeholder="e.g. 荣誉表彰" /></span>&nbsp;<small>NO.3</small>
                        </h1>
                    </div>
                    <div class="sec-content">	
                        <table class="content-table">
                                <thead>
                                        <tr>
                                                <td><strong><input name="nbitem3_col1_name" type="text" placeholder="e.g. 名称"  /></strong></td>
                                                <td><strong><input name="nbitem3_col2_name" type="text" placeholder="e.g. 奖项"  /></strong></td>
                                                <td><strong><input name="nbitem3_col3_name" type="text" placeholder="e.g. 时间"  /></strong></td>
                                        </tr>
                                </thead>
                                <tbody>
                                        <tr>
                                                <td><input name="nbitem3_11_val" type="text" /></td>
                                                <td><input name="nbitem3_12_val" type="text" /></td>
                                                <td><input name="nbitem3_13_val" type="text" /></td>
                                        </tr>
                                        <tr>
                                                <td><input name="nbitem3_21_val" type="text" /></td>
                                                <td><input name="nbitem3_22_val" type="text" /></td>
                                                <td><input name="nbitem3_23_val" type="text" /></td>
                                        </tr>
                                        <tr>
                                                <td><input name="nbitem3_31_val" type="text" /></td>
                                                <td><input name="nbitem3_32_val" type="text" /></td>
                                                <td><input name="nbitem3_33_val" type="text" /></td>
                                        </tr>
                                </tbody>
                        </table>
                    </div>
                </fieldset>
                </section>
                <fieldset>
                    <legend>
                        <span>自述</span>
                    </legend>
                    <textarea name="nbselfintro" style="width: 80%; height:350px;">请控制在360字以内</textarea>
                </fieldset>
                <?php
                    if(isset($wbuid) || isset($rruid))
                       echo" <input type=\"submit\" class=\"subbutton\" value=\"确认提交\"  />";
                    else
                       echo"<a href=\"http://zisheng.org\" class=\"subbutton\">登录后这里将显示提交按钮</a>"; 
                ?>
                
            </form>
            </div>
            
        </div>
    </body>
</html>
