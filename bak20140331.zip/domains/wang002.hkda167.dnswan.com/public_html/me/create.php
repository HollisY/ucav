<?php
    session_start();
    include_once( '../weibo/config.php' );
    include_once( '../weibo/weibofun.php' );
    $weibo = new SaeTClientV2( WB_AKEY , WB_SKEY , $_SESSION['token']['access_token'] );
    $uid_json = $weibo->get_uid();
    $wbuid = $uid_json['uid']; //当前登录用户的uid
    $wbprofile=$weibo->show_user_by_id($wbuid);//当前登录uid的基本信息，参考http://open.weibo.com/wiki/2/users/show
    /*用户名*/
    $file_name=$_POST['nbname'].".html";
    if(file_exists($file_name))
        $file_name.="a";
    if(!file_exists($file_name))
    {
        //$t=fopen('template.html','r');
        $template=file_get_contents('template.html');
        $f=fopen($file_name,'x');
        /*nbname*/
        $pattern="/nbname/u";
        $template=preg_replace($pattern,$_POST['nbname'],$template);
        
        /*uphoto*/
        $img_addr="../images/noname.gif";
        if(is_uploaded_file($_FILES['myfile']['tmp_name']))
        {
                $img_tmp=$_FILES['myfile']['tmp_name'];
                $dir=$_SERVER['DOCUMENT_ROOT']."/images/upload/".date("Ymd")."/"."u$wbuid";//存贮图片地址20130701/u123456789
                if(!is_dir($dir))//目录是否存在
                    mkdir($dir,0777,true);
                $org_name=$_FILES['myfile']['name'];
                //$img_name=time().$_FILES['myfile']['name'];
                //解决不同浏览器对文件类型识别问题，用正则匹配
                $pregstr="/.\w{0,}$/u";//".jpg"
                $arr=preg_split($pregstr,$org_name);
                $type=preg_replace("/^$arr[0]/u","",$org_name);
                
                $img_name=time().$type;
                $img=$dir."/".$img_name;
                if(move_uploaded_file($img_tmp,$img))
                {
                    $img_addr="http://zisheng.org/images/upload/".date("Ymd")."/"."u$wbuid"."/".$img_name;//外部访问地址和内部不一样
                }
                
        }
        else
                echo "image uploading failed!!!";
        $pattern="/uphotolink/u";
        $template=preg_replace($pattern,$img_addr,$template);
        
        /*nbemail*/
        $pattern="/nbemail/u";
        $template=preg_replace($pattern,$_POST['nbemail'],$template);
        
        /*nbphone*/
        $pattern="/nbphone/u";
        $template=preg_replace($pattern,$_POST['nbphone'],$template);
        
        /*nbschool*/
        $pattern="/nbschool/u";
        $template=preg_replace($pattern,$_POST['nbschool'],$template);
        
        /*nbdegree*/
        $pattern="/nbdegree/u";
        $template=preg_replace($pattern,$_POST['nbdegree'],$template);
        
        /*nbmajor*/
        $pattern="/nbmajor/u";
        $template=preg_replace($pattern,$_POST['nbmajor'],$template);
        
        /*nbinfo1*/
        $pattern="/nbinfo1/u";
        $template=preg_replace($pattern,$_POST['nbinfo1'],$template);
        
        /*nbinfoval1*/
        $pattern="/nbinfoval1/u";
        $template=preg_replace($pattern,$_POST['nbinfoval1'],$template);
        
        /*nbinfo2*/
        $pattern="/nbinfo2/u";
        $template=preg_replace($pattern,$_POST['nbinfo2'],$template);
        
        /*nbinfoval2*/
        $pattern="/nbinfoval2/u";
        $template=preg_replace($pattern,$_POST['nbinfoval2'],$template);
        
        for($x=1;$x<4;$x++)
        {   
            if(isset($_POST['nbitem'.$x.'_name']))
            {
                /*nbitem1_name*/
                $pattern='/nbitem'.$x.'_name/u';
                $template=preg_replace($pattern,$_POST['nbitem'.$x.'_name'],$template); 
                
                /*nbitem1_col1_name*/
                for($j=1;$j<4;$j++)
                    if(isset($_POST['nbitem'.$x.'_col'.$j.'_name']))
                    {
                        /*nbitem1_col1_name*/
                        $pattern='/nbitem'.$x.'_col'.$j.'_name/u';
                        $template=preg_replace($pattern,$_POST['nbitem'.$x.'_col'.$j.'_name'],$template);
                    }
                    
                /*nbitem1_11_val*/    
                for($i=1;$i<4;$i++)
                {   for($j=1;$j<4;$j++)
                        if(isset($_POST['nbitem'.$x.'_'.$i.$j.'_val']))
                        {
                            /*nbitem1_11_val*/
                            $pattern='/nbitem'.$x.'_'.$i.$j.'_val/u';
                            $template=preg_replace($pattern,$_POST['nbitem'.$x.'_'.$i.$j.'_val'],$template);
                        }
                }
                
            }
        }
        
        /*nbselfintro*/
        /*其中换行符*/
        $pattern="/\n|\r/u";
        $nbselfintrotext=preg_replace($pattern,"<br/>",$_POST['nbselfintro']);
        $pattern="/nbselfintro/u";
        $template=preg_replace($pattern,$nbselfintrotext,$template);
        
        
        if(fwrite($f,$template))
            echo "ok ^_^你的<a href=\"http://zisheng.org/me/$file_name\">简历地址</a>";
        //fclose($t);
        fclose($f);
    }
?>