$(document).ready(function(){
    maxNum=6;
    $("#q-num").click(function(){
        $.ajax({
        type:"GET",
        url:"../isonline.php",
        data:{'myk':'da2f632dc97b861b101c58f4ac0dd8c2'},
        success:function (d) {
            var wbstatus=d['wbstatus'];
            var rrstatus=d['rrstatus'];
            if (wbstatus==true || rrstatus==true) {
                $("#q-num")[0].innerHTML="15605160158";    
            }
            else{
                choice=window.confirm("先回首页去登录吧←_←");
                if (choice) {
                    window.location="../index.php";
                }
            }
        }
        });    
    });
    
    $(document).scroll(function(){
        for (var i=0;i<maxNum;i++) {
            if ($(this).scrollTop()>=($("#link"+i).offset().top-$(document).height()/15)) {
               //console.log("link"+i);
               $("#ank"+i).css({
                    "background":"#0088cc"
                });
               $(".anklist").children().not("#ank"+i).css({
                    "background":"#fff"
               })
               
            }    
        }
        
    });
    /*
     *不能循环赋值，closure”
     *for (var j=0;j<maxNum;j++) {
        $("#ank"+j).bind('click',function(event){
            event.preventDefault();
            $('body,html').animate(
                {scrollTop:($("#link"+j).offset().top)},
                500   
            );
        });    
    }
     *$(".anklist").children().click(function(event){
        event.preventDefault();
        $('body,html').animate(
            {scrollTop:$(this).offset().top},
            500    
        );
    });
    */
    for (var i=0;i<6;i++) {
        //闭包扩展i作用域
        $("#ank"+i).bind('click',(function(num){
            return function(){
                //var count=event.currentTarget.hash.substr(5);//.hash="#linkN"
                event.preventDefault();
                $('body,html').animate(
                    {scrollTop:($("#link"+num).offset().top)},
                    500
                );
            }
            })(i)
        );         
    }
});
/**
target.innerHTML=function(i){
   return function(){
        return i;
   };
}(i);
**/

