<?php
    $dbuser="wang002_wb";
    $dbpassword="199139wb";
    $dbname="wang002_wb";
    $dbhost="localhost";
    //zsdb('web3531472_wb','199139wb','web3531472_users','localhost');
?>