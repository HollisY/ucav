<?php include_once'header.php'; ?>
  <div class="search">
      <span>搜索你要的书本</span>
<script>
  (function() {
    var cx = '004946305775346921850:buuy8gr3sgm';
    var gcse = document.createElement('script');
    gcse.type = 'text/javascript';
    gcse.async = true;
    gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
        '//www.google.com/cse/cse.js?cx=' + cx;
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(gcse, s);
  })();
</script>
<gcse:search></gcse:search>
  </div>
  <?php include_once'footer.php'; ?>
 </body>
</html>









